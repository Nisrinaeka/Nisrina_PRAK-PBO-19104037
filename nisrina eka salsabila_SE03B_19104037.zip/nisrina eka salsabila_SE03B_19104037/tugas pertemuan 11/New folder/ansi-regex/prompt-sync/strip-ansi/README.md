strip-ansi Build Status
Strip ANSI escape codes from a string

Get professional support for 'strip-ansi' with a Tidelift subscription
Tidelift helps make open source sustainable for maintainers while giving companies
assurances about security, maintenance, and licensing for their dependencies.
Install
$ npm install strip-ansi
Usage
const stripAnsi = require('strip-ansi');

stripAnsi('\u001B[4mUnicorn\u001B[0m');
//=> 'Unicorn'

stripAnsi('\u001B]8;;https://github.com\u0007Click\u001B]8;;\u0007');
//=> 'Click'
Security
To report a security vulnerability, please use the Tidelift security contact. Tidelift will coordinate the fix and disclosure.

Related
strip-ansi-cli - CLI for this module
strip-ansi-stream - Streaming version of this module
has-ansi - Check if a string has ANSI escape codes
ansi-regex - Regular expression for matching ANSI escape codes
chalk - Terminal string styling done right
Maintainers
Sindre Sorhus
Josh Junon
License
MITssss